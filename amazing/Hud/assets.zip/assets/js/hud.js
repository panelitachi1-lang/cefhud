var main = new Vue({
    el: ".amazing-main-hud-block",

    data:
    {
        active: false,
        health: 0,
        id: 0,
        name: "",
        data: "",
        time: "",
        armour: 0,
        wanted: 0,
        money: 0,
        weapon: 0,
        ammo: 0,
        isAdmin: false // Добавляем поле для статуса админа
    },

    methods:
    {
        getInterface() 
        {
            return this.removeUnderscores(this.name);
        },
        removeUnderscores(str) {
            if (!str) return '';
            return str.replace(/_/g, ' ');
        },
        formatNumber(value) {
            return new Intl.NumberFormat('ru-RU', {
                style: 'decimal',
                minimumFractionDigits: 0
            }).format(value);
        },
        updateData() 
        {
            this.data = String(new Date().getDate()).padStart(2, '0') + '.' + 
                       String(new Date().getMonth() + 1).padStart(2, '0') + '.' + 
                       String(new Date().getFullYear() % 100).padStart(2, '0');

            const result = {
                timeZone: 'Europe/Moscow',
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };

            this.time = new Date().toLocaleString('ru-RU', result);
        }
    },

    computed:
    {
        healthDasharray() 
        {
            return 2 * Math.PI * 180;
        },
        healthDashoffset() 
        {
            return this.healthDasharray * (1 - this.health / 100);
        },
        IsWeaponFire() 
        {
            return this.weapon >= 22 && this.weapon <= 38 || this.weapon == 41 || this.weapon == 42;
        },
        idClass() {
        return {
            'admin-id': this.isAdmin,
            'user-id': !this.isAdmin
        };
    }
        
    },
    
    mounted()
    {
        setInterval(() => this.updateData(), 500);
        this.updateData(); // Инициализируем сразу
        
        cef.on("Lethality(executeEvent['main.hud.active'])", active => this.active = active);
        cef.on("Lethality(executeEvent['main.hud.wanted'])", wanted => this.wanted = wanted);
        cef.on("Lethality(executeEvent['main.hud.id'])", ID => this.id = ID);
        cef.on("Lethality(executeEvent['main.hud.name'])", name => this.name = name);
        cef.on("Lethality(executeEvent['main.hud.admin'])", isAdmin => this.isAdmin = isAdmin);
    }
});

// Остальной код без изменений
cef.emit("game:hud:setComponentVisible", "interface", false);
cef.emit("game:hud:setComponentVisible", "radar", true);
cef.emit("game:data:pollPlayerStats", true, 50);

cef.on("game:data:playerStats", (hp, max_hp, arm, breath, wanted, weapon, ammo, max_ammo, money, speed) => {
    main.armour = Math.round(arm);
    main.health = Math.round(hp);
    main.money = money;
    main.weapon = weapon;
    main.ammo = ammo + '/' + Math.max(0, max_ammo - ammo);

    state.speed = speed;
    updateSpeedometer();
});