// SPEEDOMETER BY MATVEY TABLETKA 
let state = 
{
  speed: 0,
  maxSpeed: 300,
  fuelValue: 100,
  fuelCapacity: 100,
  strength: 1000,
  mileage: 0,
};

const speedValue = document.querySelector('.speed-value');
const mileageValue = document.querySelector('.mileage-value');
const arrowAnchor = document.querySelector('.arrow__anchor');
const indicators = document.querySelectorAll('.scale__indicators .indicator');
const fuelBar = document.querySelector('.fuel-bar .bar');
const strengthBar = document.querySelector('.strength-bar .bar');

function map(value, inMin, inMax, outMin, outMax) {
  if (inMax === inMin) return outMin;
  return ((value - inMin) * (outMax - outMin)) / (inMax - inMin) + outMin;
}

function drawCircleProgressBar(canvas, progress, angle, strokeWidth, strokeColor, progressColor, clockwise = false) {
  const ctx = canvas.getContext('2d');
  const size = canvas.width;
  const center = size / 2;
  const radius = (size - strokeWidth) / 2;
  const startAngle = Math.PI * 1.5;
  const maxAngle = (Math.PI * 2 * angle) / 360;
  const progressAngle = (maxAngle * progress) / 100;

  ctx.clearRect(0, 0, size, size);

  // Background stroke
  ctx.beginPath();
  ctx.arc(center, center, radius, startAngle, startAngle + maxAngle, clockwise);
  ctx.lineWidth = strokeWidth;
  ctx.strokeStyle = strokeColor;
  ctx.stroke();

  // Progress stroke
  ctx.beginPath();
  ctx.arc(center, center, radius, startAngle, startAngle + progressAngle, clockwise);
  ctx.lineWidth = strokeWidth;
  ctx.strokeStyle = progressColor;
  ctx.stroke();
}

function updateSpeedometer() {
  console.log('Updating speedometer. Speed:', state.speed, 'Rotation:', map(state.speed, 0, state.maxSpeed, 0, 158));
  
  // Update Speed Value
  speedValue.textContent = Math.round(state.speed);

  // Update Mileage
  mileageValue.textContent = String(Math.round(state.mileage)).padStart(6, '0');

  // Update Speed Scale
  const rotation = map(state.speed, 0, state.maxSpeed, 0, 158);
  console.log('Arrow rotation:', rotation, 'degrees');
  arrowAnchor.style.transform = `rotate(${rotation}deg)`;

  // Update Indicators
  const step = state.maxSpeed / 24;
  const fullIndicators = Math.floor(state.speed / step);
  const partialIndicator = (state.speed % step) / step;
  
  console.log('Indicators - full:', fullIndicators, 'partial:', partialIndicator);
  
  indicators.forEach((indicator, index) => {
    if (index < fullIndicators) {
      indicator.style.opacity = 1;
    } else if (index === fullIndicators) {
      indicator.style.opacity = Math.max(0, Math.min(partialIndicator, 1));
    } else {
      indicator.style.opacity = 0;
    }
  });
  
  // Update Fuel Bar
  const fuelProgress = (state.fuelValue / state.fuelCapacity) * 100;
  drawCircleProgressBar(fuelBar, fuelProgress, 48, 5, 'rgba(255, 255, 255, 0.3)', '#F3BE00', false);

  // Update Strength Bar
  const strengthProgress = map(state.strength, 333, 1000, 0, 100);
  drawCircleProgressBar(strengthBar, strengthProgress, 32, 5, 'rgba(255, 255, 255, 0.3)', '#FFFFFF', false);
}

function updateBar(type, value) {
    console.log('Updating bar:', type, value);
    
    if (type === 'fuel') {
      state.fuelValue = Math.max(0, Math.min(value, state.fuelCapacity));
      const fuelProgress = (state.fuelValue / state.fuelCapacity) * 100;
      drawCircleProgressBar(fuelBar, fuelProgress, 48, 5, 'rgba(255, 255, 255, 0.3)', '#F3BE00', false);
    } else if (type === 'strength') {
      state.strength = Math.max(333, Math.min(value, 1000));
      const strengthProgress = map(state.strength, 333, 1000, 0, 100);
      drawCircleProgressBar(strengthBar, strengthProgress, 32, 5, 'rgba(255, 255, 255, 0.3)', '#FFFFFF', false);
    }
    
    updateSpeedometer();
}
  
function toggleSpeedometer(f) {
  console.log('Toggle speedometer:', f);
  const speedometer = document.querySelector('.speedometer');
  if (!speedometer) {
    console.error('Speedometer element not found!');
    return;
  }
  
  if (f == 1) {
    speedometer.style.display = 'block';
    console.log('Speedometer shown');
  } else {
    speedometer.style.display = 'none';
    console.log('Speedometer hidden');
  }
}

// Инициализация индикаторов
function initializeIndicators() {
    console.log('Initializing indicators...');
    const indicatorsContainer = document.querySelector('.scale__indicators');
    if (!indicatorsContainer) {
        console.error('Indicators container not found!');
        return;
    }
    
    const totalIndicators = 24;
    
    // Очищаем существующие индикаторы
    indicatorsContainer.innerHTML = '';
    
    for (let i = 0; i < totalIndicators; i++) {
        const indicator = document.createElement('div');
        indicator.className = 'indicator';
        indicator.style.position = 'absolute';
        indicator.style.width = '2px';
        indicator.style.height = '10px';
        indicator.style.background = 'white';
        indicator.style.opacity = '0';
        indicator.style.transition = 'opacity 0.3s';
        
        // Распределяем индикаторы по кругу (158 градусов)
        const angle = (158 / totalIndicators) * i;
        const rad = (angle * Math.PI) / 180;
        const radius = 85;
        
        const x = 100 + Math.cos(rad) * radius;
        const y = 100 + Math.sin(rad) * radius;
        
        indicator.style.left = `${x}px`;
        indicator.style.top = `${y}px`;
        indicator.style.transform = `rotate(${angle}deg)`;
        indicator.style.transformOrigin = 'center center';
        
        indicatorsContainer.appendChild(indicator);
    }
    
    console.log('Indicators initialized:', totalIndicators);
}

// Обработчики событий от сервера
cef.on("game:SetSpeed", (speed, mileage) => {
    console.log('Received speed:', speed, 'mileage:', mileage);
    state.speed = Math.min(speed, state.maxSpeed);
    state.mileage = mileage;
    updateSpeedometer();
});

cef.on("game:SetSpeedFuel", (fuel) => {
    console.log('Received fuel:', fuel);
    updateBar('fuel', fuel);
});

cef.on("game:SetSpeedHealth", (health) => {
    console.log('Received health:', health);
    updateBar('strength', health);
});

cef.on("game:SetSpeedEngine", (engine) => {
    console.log('Received engine:', engine);
    const engineIndicator = document.querySelector('.engine-indicator .icon');
    if (engineIndicator) {
        engine ? engineIndicator.style.background = '#69da67' : engineIndicator.style.background = '#ffffff80';
    }
});

cef.on("game:SetSpeedDoors", (doors) => {
    console.log('Received doors:', doors);
    const doorsIndicator = document.querySelector('.doors-indicator .icon');
    if (doorsIndicator) {
        doors ? doorsIndicator.style.background = '#69da67' : doorsIndicator.style.background = '#ffffff80';
    }
});

cef.on("game:SetSpeedLights", (lights) => {
    console.log('Received lights:', lights);
    const headlightsIndicator = document.querySelector('.headlights-indicator .icon');
    if (headlightsIndicator) {
        lights ? headlightsIndicator.style.background = '#69da67' : headlightsIndicator.style.background = '#ffffff80';
    }
});

cef.on("game:ToggleSpeedometer", (show) => {
    console.log('Received toggle:', show);
    toggleSpeedometer(show ? 1 : 0);
});

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing speedometer...');
    
    // Проверяем наличие всех элементов
    const elements = {
        speedValue: document.querySelector('.speed-value'),
        mileageValue: document.querySelector('.mileage-value'),
        arrowAnchor: document.querySelector('.arrow__anchor'),
        fuelBar: document.querySelector('.fuel-bar .bar'),
        strengthBar: document.querySelector('.strength-bar .bar'),
        speedometer: document.querySelector('.speedometer')
    };
    
    for (const [name, element] of Object.entries(elements)) {
        if (!element) {
            console.error('Element not found:', name);
        } else {
            console.log('Element found:', name);
        }
    }
    
    initializeIndicators();
    updateSpeedometer();
    
    // Тестовые данные для проверки
    setTimeout(() => {
        console.log('Running test update...');
        state.speed = 120;
        state.fuelValue = 75;
        state.strength = 800;
        updateSpeedometer();
    }, 1000);
});

// Функция для ручного тестирования (можно вызвать из консоли браузера)
window.testSpeedometer = function(speed = 100, fuel = 50, strength = 750) {
    state.speed = speed;
    state.fuelValue = fuel;
    state.strength = strength;
    updateSpeedometer();
    console.log('Test values set - speed:', speed, 'fuel:', fuel, 'strength:', strength);
};

console.log('Speedometer script loaded');